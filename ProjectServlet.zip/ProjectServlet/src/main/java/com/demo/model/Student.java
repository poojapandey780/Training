package com.demo.model;

public class Student {
	private Long id;
	private String name;
	private String email;
	private String password;
	private String address;
	private String address1;
	private String city;
	private String State;
	private String 
}
