package com.demo.model;

import java.util.List;

public class Student {
	private Long id;
	private String name;
	private String email;
	private String password;
	private String address;
	private String address1;
	private String city;
	private String State;
	private int zipCode;
	private String resumePaths;
	private List<String> imagePaths;
	
	public Long getId() {return id;}
	public String getName() {return name;}
	public String getEmail() {return email;}
	public String getPassword() {return password;}
	public String getAddress() {return address;}
	public String getAddress1() {return address1;}
	public String getCity() {return city;}
	public String getState() {return State;}
	public int getZipCode() {return zipCode;}
	public String getResumePaths() {return resumePaths;}
	public List<String> getImagePaths() {return imagePaths;}
	
	
	
	public void setId(Long id) {this.id = id;}
	public void setName(String name) {this.name = name;}
	public void setEmail(String email) {this.email = email;}
	public void setPassword(String password) {this.password = password;}
	public void setAddress(String address) {this.address = address;}
	public void setAddress1(String address1) {this.address1 = address1;}
	public void setCity(String city) {this.city=city;}
	public void setState(String state) {this.State=state;}
	public void setZipCode(int zipCode) {this.zipCode = zipCode;}
	public void setResumePaths(String resumePaths) {this.resumePaths=resumePaths;}
	public void setImagePaths(List<String> imagePaths) {this.imagePaths=imagePaths;}
	
}
