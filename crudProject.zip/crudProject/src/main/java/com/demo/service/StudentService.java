package com.demo.service;

import com.demo.dao.StudentDao;
import com.demo.model.Student;

public class StudentService {
	
	public StudentDao studentDao = new StudentDao();
	
//create or save student in database
	public String createStudent(Student student) {
		boolean isSaved = studentDao.saveStudent(student);

        if (isSaved) {
            return "Student '" + student.getName() + "' was successfully saved!";
        } else {
            return "Failed to save student '" + student.getName() + "'. Please try again.";
        }	
        
	}
}
