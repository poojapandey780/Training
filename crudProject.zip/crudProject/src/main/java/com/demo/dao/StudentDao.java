package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.demo.model.Student;
import com.demo.util.DbUtil;

public class StudentDao {

    public boolean saveStudent(Student student) {
        // Use snake_case for column names
        String query = "INSERT INTO student " +
                       "(name, email, password, address, address1, city, state, zip_code, resume_paths, image_paths) " +
                       "VALUES (?,?,?,?,?,?,?,?,?,?)";

        try (Connection con = DbUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getPassword());
            ps.setString(4, student.getAddress());
            ps.setString(5, student.getAddress1());
            ps.setString(6, student.getCity());
            ps.setString(7, student.getState());
            ps.setInt(8, student.getZipCode());
            ps.setString(9, student.getResumePaths());
            
            System.out.println("Query about to run: " + query);
            System.out.println("Name: " + student.getName());
            System.out.println("Email: " + student.getEmail());
            System.out.println("Resume: " + student.getResumePaths());
            System.out.println("Images: " + student.getImagePaths());

            
            System.out.println(student.getName() + " , " + student.getEmail());

            // Convert List<String> to comma-separated string
            if (student.getImagePaths() != null && !student.getImagePaths().isEmpty()) {
                ps.setString(10, String.join(",", student.getImagePaths()));
            } else {
                ps.setString(10, null);
            }

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }
}
