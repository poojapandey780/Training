package com.demo.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {

	    private static final String url = "jdbc:mysql://localhost:3306/dbcrud";
	    private static final String user = "root";
	    private static final String password = "455445";

	    public static Connection getConnection() throws Exception {
	   // Loads the MySQL JDBC driver into memory. 	
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        return DriverManager.getConnection(url, user, password);
	    }
}


