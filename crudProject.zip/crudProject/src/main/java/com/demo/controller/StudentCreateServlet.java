package com.demo.controller;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.demo.model.Student;
import com.demo.service.StudentService;

@MultipartConfig   // this is used for handles files
public class StudentCreateServlet extends HttpServlet{
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		String name = req.getParameter("name");
		String email= req.getParameter("email");
		String password = req.getParameter("password");
		String address = req.getParameter("address");
		String address2 = req.getParameter("address2");
		String city = req.getParameter("city");
		String state = req.getParameter("state");
		int zip = Integer.parseInt(req.getParameter("zipcode"));
		Part resume = req.getPart("resume");
		
		
		String uploadPathResume = "C:\\Learning\\Learn Internship" + File.separator+ "uploadsResume";
		File uploadDir = new File(uploadPathResume);
		if (!uploadDir.exists()) {
		    uploadDir.mkdirs();   //  creates the folder
		}
		String resumeName = resume.getSubmittedFileName();
		
//		save file physically
		resume.write(uploadPathResume + File.separator +resumeName);
//		save this in model/db
		String resumePath = "uploadsResume/" +resumeName;
		
				
//		Multiple iMAGES UPLOAD------------------------------------------------------------------------
		String imagePath = "C:\\Learning\\Learn Internship/uploadImage";
        File imageDir = new File(imagePath);
        if (!imageDir.exists()) {
            imageDir.mkdirs();
        }
        List<String> imagesPaths = new ArrayList<>();

        for (Part part : req.getParts()) {

        	//  VERY IMPORTANT FILTER
            if ("images".equals(part.getName())
                    && part.getSubmittedFileName() != null
                    && part.getSize() > 0) {
            	String imageName = part.getSubmittedFileName();
//            	save file physically
                part.write(imagePath + File.separator + imageName);
                
                String imagePaths = "uploadImage/" +imageName;
                imagesPaths.add(imagePaths);
            }
        }
        
        
        Student stu = new Student();
        stu.setName(name);
        stu.setEmail(email);
        stu.setPassword(password);
        stu.setAddress(address);
        stu.setAddress1(address2);
        stu.setCity(city);
        stu.setState(state);
        stu.setZipCode(zip);
        stu.setResumePaths(resumePath);
        stu.setImagePaths(imagesPaths);
        
        StudentService studentService = new StudentService();
        String message = studentService.createStudent(stu);

        // Pass the message to JSP page
        
        req.setAttribute("msg", message);
        req.getRequestDispatcher("/index.jsp").forward(req, res);
	}
}
